import pandas as pd
import os
import shutil

import glob

def create_pseudo_labels(input_csv, threshold_real=0.3, threshold_fake=0.7):
    df = pd.read_csv(input_csv)
    
    # Filter high confidence predictions
    real_samples = df[df['prob'] < threshold_real].copy()
    fake_samples = df[df['prob'] > threshold_fake].copy()
    
    # Assign labels
    real_samples['label'] = 0
    fake_samples['label'] = 1
    
    pseudo_df = pd.concat([real_samples, fake_samples])
    
    print(f"Total Test Samples: {len(df)}")
    print(f"Selected Real (Label 0): {len(real_samples)}")
    print(f"Selected Fake (Label 1): {len(fake_samples)}")
    print(f"Total Pseudo Videos: {len(pseudo_df)} ({len(pseudo_df)/len(df)*100:.1f}%)")
    
    valid_rows = []
    processed_dir = os.path.abspath('data/processed/test') # Use absolute path
    
    print(f"Checking images in: {processed_dir}")

    for idx, row in pseudo_df.iterrows():
        filename = row['filename']
        file_base = os.path.splitext(filename)[0]
        
        # Look for folder
        video_folder = os.path.join(processed_dir, file_base)
        
        if os.path.isdir(video_folder):
            # Glob all jpgs in the folder
            frames = glob.glob(os.path.join(video_folder, '*.jpg'))
            if not frames:
                if idx == 0: print(f"DEBUG: Folder exists but empty? {video_folder}")
                continue
                
            for frame_path in frames:
                valid_rows.append({'path': frame_path, 'label': row['label']})
        else:
            if idx == 0: print(f"DEBUG: Failed to find folder {video_folder}")
        
    final_pseudo_df = pd.DataFrame(valid_rows)
    output_path = 'data/pseudo_train.csv'
    final_pseudo_df.to_csv(output_path, index=False)
    print(f"Saved {len(final_pseudo_df)} valid pseudo-labeled frames to {output_path}")

if __name__ == "__main__":
    create_pseudo_labels('data/submission/final_ensemble_v2.csv')